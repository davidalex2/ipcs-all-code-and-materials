package com.algoriant.sms.model;

public class Authorities {
    public String getAuthority() {
        return authority;
    }

    public void setAuthority(String authority) {
        this.authority = authority;
    }

    private  String authority;
}
