package com.algoriant.sms.service;

import com.algoriant.sms.model.Student;
import com.algoriant.sms.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;


@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    public Student createStudent(Student student) {
        studentRepository.save(student);
        return student;
    }
    public void deleteStudent(int uid) {
        studentRepository.deleteById(uid);
    }
    public Student updateStudent(Student student, int uid) {
        student.setId(uid);
       return studentRepository.save(student);
    }

    public Student getStudent(int uid) {
        return studentRepository.findById(uid).get();
    }

    public List<Student> getAllStudent() {
        List<Student> list=new ArrayList<Student>();
        studentRepository.findAll().forEach(list::add);
        return list;
    }
}
