package com.algoriant.sms.model;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name="student")
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    @Column
    private String name;
    @Column
    private String dept;
    @Column
    private Date dob;

    public void setId(int id) {
        this.id=id;
    }
    public int getId() {
        return  id;
    }
    public void setName(String name) {
        this.name=name;
    }
    public String getName() {
        return name;
    }
    public void setDept(String dept) {
        this.dept=dept;
    }
    public String getDept() {
        return dept;
    }
    public void setDob(Date dob) {
        this.dob=dob;
    }
    public Date getDob() {
        return dob;
    }
}
