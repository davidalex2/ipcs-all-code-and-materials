package com.algoriant.sms.controller;

import com.algoriant.sms.model.Student;
import com.algoriant.sms.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/student")
public class StudentController {
    @Autowired
private StudentService studentService;
    @PostMapping("/createStudent")
    public ResponseEntity<Student> createStudent(@RequestBody Student student) {
        studentService.createStudent(student);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }
    @GetMapping("/getAllStudent")
    public ResponseEntity<List<Student>> getAllStudent(){
        List<Student> student=studentService.getAllStudent();
        return new ResponseEntity<>(student,HttpStatus.OK);
    }
    @GetMapping("/getStudent/{uid}")
    public ResponseEntity<Student> getStudent(@PathVariable("uid") int uid){
        Student student=studentService.getStudent(uid);
        return new ResponseEntity<>(student,HttpStatus.OK);
    }

    @PutMapping("/updateStudent/{id}")
    public ResponseEntity<Student> updateStudent( @PathVariable("id") int id,@RequestBody Student student) {
        studentService.updateStudent(student,id);
        return new ResponseEntity<>(HttpStatus.OK);
    }
    @DeleteMapping("/deleteStudent/{id}")
    public ResponseEntity<Student> deleteStudent(@PathVariable("id")int uid) {
        studentService.deleteStudent(uid);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}